# Real data application: preprocessing for the U.S. Senate cosponsorship network
#
# This script constructs a 50 x 50 x 52 adjacency array of yearly
# state-level cosponsorship networks from 1973 to 2024.
# Period 1 (1973--2004) uses the Fowler et al. (2007), 
# and Period 2  (2005--2024) uses bill status data from govinfo.
# The final output is A_arr_all, which is saved for the data example.
#
## Period 1(1973 -- 2004) (Data from Fowler et al. (2007))
library(stringr)
library(tidyverse)
library(xml2)
library(Matrix)
library(dplyr)
library(readr)
years_hd <- 1973:2004

## ---- Paths --------------------------------------------------
DATA_DIR <- "Data"

COSponsor_DIR <- file.path(DATA_DIR, "Cosponsor")
GOVINFO_DIR   <- file.path(DATA_DIR, "GovInfo_BILLSTATUS")
VOTEVIEW_PATH <- file.path(DATA_DIR, "Hsall_members.csv")

## Period 1 files
bills_vec    <- read_lines(file.path(COSponsor_DIR, "bills.txt"))
senator      <- read_csv(file.path(COSponsor_DIR, "senate.csv"))
dates_vec    <- read_lines(file.path(COSponsor_DIR, "dates.txt"))
sponsors_vec <- read_lines(file.path(COSponsor_DIR, "sponsors.txt"))
cosps_vec    <- read_lines(file.path(COSponsor_DIR, "cosponsors.txt"))

vv <- read_csv(
  VOTEVIEW_PATH,
  col_types = cols(
    congress      = col_integer(),
    chamber       = col_character(),
    icpsr         = col_integer(),
    state_abbrev  = col_character()
  )
) %>% 
  filter(chamber == "Senate", congress %in% 93:108) %>% 
  transmute(
    congress,
    id = icpsr,
    state = state_abbrev
)

senator <- senator %>%                       
  left_join(vv, by = c("congress", "id"))

senator <- as.data.frame(senator)
state_levels <- state.abb
p <- length(state_levels)

A_arr <- array(
  0L,
  dim = c(p, p, length(years_hd)),
  dimnames = list(state_levels, state_levels, as.character(years_hd))
)

is_sn <- str_detect(bills_vec, "^SN")

split_line <- function(x) {
  if (x %in% c("NA", "")) character(0) else str_split(x, "\\s+")[[1]]
}

for (k in seq_along(years_hd)) {
  yy <- years_hd[k]
  sn_idx <- which(is_sn & str_detect(dates_vec, paste0("^", yy)))
  if (!length(sn_idx)) next
  
  bill_ids <- str_remove(bills_vec[sn_idx], "\\.txt$")
  cg <- floor((yy - 1973) / 2) + 93
  se_cg <- senator[senator$congress == cg, , drop = FALSE]
  se_cg <- se_cg[!is.na(se_cg$state) & se_cg$state %in% state_levels, , drop = FALSE]
  if (!nrow(se_cg)) next
  Ms <- matrix(0L, nrow = p, ncol = length(sn_idx),
               dimnames = list(state_levels, bill_ids))
  
  for (j in seq_along(sn_idx)) {
    g <- sn_idx[j]
    ids <- c(sponsors_vec[g], split_line(cosps_vec[g]))
    ids <- ids[ ids != "" & ids != "NA" & str_detect(ids, "^[0-9]+$") ]
    if (!length(ids)) next
    
    ids_int <- as.integer(ids)
    pos <- match(ids_int, se_cg$id)
    pos <- pos[!is.na(pos)]
    if (!length(pos)) next
    
    st <- se_cg$state[pos]
    st <- st[!is.na(st) & st %in% state_levels]
    if (!length(st)) next
    
    tab <- table(st)
    Ms[match(names(tab), state_levels), j] <- as.integer(tab)
  }
  StateMat <- Ms %*% t(Ms)
  diag(StateMat) <- 0L
  thr <- mean(StateMat[upper.tri(StateMat)])
  A1 <- ifelse(StateMat > thr, 1L, 0L)
  diag(A1) <- 0L
  A_arr[, , k] <- A1
}

### Period 2(2005 -- 2024) (Data from govinfo.gov/bulkdata/~)
root <- "/Users/jeonghwanlee/Library/CloudStorage/Dropbox/Research_Network/Cosponsorship_dat"
folders <- file.path(root, paste0("BILLSTATUS-", 109:118, "-s"))
state_levels <- state.abb
p <- length(state_levels)

extract_state <- function(fullname) {
  m <- str_match(fullname, "\\[[A-Z]+-([A-Z]{2})(?:-[0-9]+)?\\]$")
  m[,2]
}

read_one_bill <- function(f) {
  x <- read_xml(f)
  intro <- xml_text(xml_find_first(x, ".//introducedDate"))
  if (is.na(intro) || intro == "") return(NULL)
  year <- as.integer(substr(intro, 1, 4))
  
  bill_id <- str_remove(basename(f), "\\.xml$")
  
  sp_full <- xml_text(xml_find_first(x, ".//sponsors/item/fullName"))
  co_full <- xml_text(xml_find_all(x, ".//cosponsors/item/fullName"))
  
  full <- c(sp_full, co_full)
  full <- full[!is.na(full) & full != ""]
  if (!length(full)) return(NULL)
  
  st <- extract_state(full)
  st <- st[!is.na(st) & st %in% state_levels]
  if (!length(st)) return(NULL)
  
  list(year = year, bill = bill_id, states = st)
}

build_A1_for_year <- function(yy) {
  files <- unlist(lapply(folders, list.files, pattern="\\.xml$", full.names=TRUE))
  parsed <- lapply(files, read_one_bill)
  parsed <- Filter(Negate(is.null), parsed)
  parsed <- Filter(function(z) z$year == yy, parsed)
  if (!length(parsed)) return(NULL)
  
  bills <- vapply(parsed, `[[`, "", "bill")
  
  Ms <- Matrix(0, nrow=p, ncol=length(bills), sparse=TRUE,
               dimnames=list(state_levels, bills))
  
  for (j in seq_along(parsed)) {
    tab <- table(parsed[[j]]$states)
    ii <- match(names(tab), state_levels)
    Ms[ii, j] <- as.integer(tab)
  }
  
  StateMat <- as.matrix(Ms %*% t(Ms))
  diag(StateMat) <- 0L
  
  thr <- mean(StateMat[upper.tri(StateMat)])
  A1  <- ifelse(StateMat > thr, 1L, 0L)
  diag(A1) <- 0L
  A1
}

years_gov <- 2005:2024
A_arr_gov <- array(0L,
                   dim = c(p, p, length(years_gov)),
                   dimnames = list(state_levels, state_levels, as.character(years_gov))
)

for (k in seq_along(years_gov)) {
  yy <- years_gov[k]
  A1 <- build_A1_for_year(yy)
  if (is.null(A1)) next
  A_arr_gov[, , k] <- A1
}

A_arr_all <- array(
  0L,
  dim = c(50, 50, dim(A_arr)[3] + dim(A_arr_gov)[3]),
  dimnames = list(
    dimnames(A_arr)[[1]],
    dimnames(A_arr)[[2]],
    c(dimnames(A_arr)[[3]], dimnames(A_arr_gov)[[3]])
  )
)

A_arr_all[,, seq_len(dim(A_arr)[3])] <- A_arr
A_arr_all[,, (dim(A_arr)[3] + 1):(dim(A_arr)[3] + dim(A_arr_gov)[3])] <- A_arr_gov
#saveRDS(A_arr_all, file="Data/Cosponsor_Adj.rds")



## Party membership info: build a 50 x 52 state-by-year matrix
## with status in {"DD", "RR", "DR"} based on the two Senate seats
## each state held in each year (mapped via Congress number).
##
## Source: Voteview Hsall_members.csv (covers Congresses 93-118 = 1973-2024).
## Independents are treated as caucusing with Democrats (modern convention);
## change classify_pair() if you prefer a different rule.
years_all    <- 1973:2024
state_levels <- state.abb
p            <- length(state_levels)        # 50
T_len        <- length(years_all)           # 52

# 93rd Congress = 1973-1974, 94th = 1975-1976, ..., 118th = 2023-2024
year_to_congress <- function(yy) floor((yy - 1973) / 2) + 93

## Senate roster with party from Voteview
vv_party <- read_csv(
  "Data/Hsall_members.csv",
  col_types = cols(
    congress     = col_integer(),
    chamber      = col_character(),
    icpsr        = col_integer(),
    state_abbrev = col_character(),
    party_code   = col_integer()
  )
) %>%
  filter(chamber == "Senate", congress %in% 93:118) %>%
  transmute(
    congress,
    state = state_abbrev,
    party = case_when(
      party_code == 100 ~ "D",
      party_code == 200 ~ "R",
      TRUE              ~ "I"     # Independents (e.g., Sanders, King, Jeffords)
    )
  ) %>%
  filter(state %in% state_levels)

## Classify the seats held in a (state, congress) into DD / RR / DR.
## Mid-term replacements may yield >2 senators within one Congress;
## we look at the set of distinct parties observed.
classify_pair <- function(parties) {
  parties <- parties[!is.na(parties)]
  if (!length(parties)) return(NA_character_)
  parties <- parties[parties %in% c("D", "R", "I")]
  if (!length(parties)) return(NA_character_)
  ord  <- c("D", "R", "I")
  uniq <- unique(parties)
  uniq <- uniq[order(match(uniq, ord))]
  if (length(uniq) == 1L) return(paste0(uniq, uniq))     
  if (length(uniq) == 2L) return(paste0(uniq[1], uniq[2]))
  paste(uniq, collapse = "")
}

sc_status <- vv_party %>%
  group_by(state, congress) %>%
  summarise(status = classify_pair(party), .groups = "drop")

## Build the 50 x 52 matrix
party_state_mat <- matrix(
  NA_character_,
  nrow     = p,
  ncol     = T_len,
  dimnames = list(state_levels, as.character(years_all))
)

for (k in seq_along(years_all)) {
  cg  <- year_to_congress(years_all[k])
  sub <- sc_status[sc_status$congress == cg, , drop = FALSE]
  ix  <- match(sub$state, state_levels)
  keep <- !is.na(ix)
  party_state_mat[ix[keep], k] <- sub$status[keep]
}

table(party_state_mat)
saveRDS(party_state_mat, file = "Data/Party_State_Mat.rds")

## Collapse all mixed-type delegations into a single "Mixed" category
party_state_mat[party_state_mat %in% c("DR", "DI", "RI", "DRI")] <- "Mixed"
party_state_mat[party_state_mat == "II"] <- "DD"   # caucus convention; change to "Mixed" if you prefer

table(party_state_mat, useNA = "ifany")
