## Basic helper and network generation functions
## ------------------------------------------------------------
library(HCD)

## Signal functions used in simulation settings.
f111 <- function(t) 1 + 0.5 * sin(2 * pi * t)
f112 <- function(t) 1 - 0.5 * sin(2 * pi * t)
f113 <- function(t) 0.5 + t

## Matrix and vector norms.
f.norm <- function(mat) sqrt(sum(abs(mat)^2))
spec.norm <- function(mat) Matrix::norm(mat, type = "2")
twoinf.norm <- function(mat) {
  row_norms <- apply(mat, 1, function(row) sqrt(sum(row^2)))
  max(row_norms)
}
two.norm <- function(vec) sqrt(sum(vec^2))
inv.logit <- function(x) {
  exp(x) / (1 + exp(x))
}

## Generation functions
## ------------------------------------------------------------

library(doParallel)
library(randnet)
library(HCD)
library(fase)


## DSBM.gen()
## Input : signal function, network size n, number of blocks K, base beta,
##         number of time layers T1, and sparsity/density multiplier rho.
## Output: A list whose first element is the adjacency array and second element
##         is the true probability array.
## Generates a dynamic SBM with common time-varying within/between probabilities.
DSBM.gen <- function(fun = f111, n = 600, K = 3, beta = 0.5,
                     T1 = 100, rho = 1) {
  block1 <- BlockModel.Gen(round(n / 12), n, beta = beta, K = K)
  g <- as.factor(block1$g)
  M <- model.matrix(~ g - 1)
  P <- block1$P
  H.arr <- array(NA, dim = c(K, K, T1))
  within.base <- unique(as.vector(P[g == 1, g == 1]))[1]
  btw.base <- unique(as.vector(P[g == 1, g == 2]))[1]
  within.prob <- within.base * fun(1:T1 / T1) * rho
  btw.prob <- btw.base * fun(1:T1 / T1) * rho
  for (k in 1:K) {
    H.arr[k, k, ] <- within.prob
  }
  for (t in 1:T1) {
    H.arr[, , t][upper.tri(H.arr[, , t])] <- btw.prob[t]
    H.arr[, , t][lower.tri(H.arr[, , t])] <- btw.prob[t]
  }
  P.arr <- array(NA, dim = c(n, n, T1))
  A.arr <- array(NA, dim = c(n, n, T1))
  
  for (t in 1:T1) {
    P.arr[, , t] <- M %*% H.arr[, , t] %*% t(M)
    diag(P.arr[, , t]) <- 0
    A.arr[, , t] <- as.matrix(gen.A.from.P(P.arr[, , t]))
  }
  res <- list()
  res[[1]] <- A.arr
  res[[2]] <- P.arr
  return(res)
}


## DSBM.npd.gen()
## Input : network size n, number of time layers T1, and two signal functions.
## Output: A list whose first element is the adjacency array and second element
##         is the true probability array.
## Generates a non-positive-definite dynamic SBM with two time-varying block patterns.
DSBM.npd.gen <- function(n = 600, K = 4, T1 = 100,
                          fun1 = f111, fun2 = f112) {
  block1 <- BlockModel.Gen(round(n / 12), n, beta = .5, K = K)
  g <- as.factor(block1$g)
  M <- model.matrix(~ g - 1)
  P <- block1$P
  
  H.arr <- array(NA, dim = c(K, K, T1))
  
  within.base <- unique(as.vector(P[g == 1, g == 1]))[1]
  btw.base <- unique(as.vector(P[g == 1, g == 2]))[1]
  
  within.prob1 <- within.base * fun1(1:T1 / T1)
  btw.prob1 <- btw.base * fun1(1:T1 / T1)
  within.prob2 <- within.base * fun2(1:T1 / T1)
  btw.prob2 <- btw.base * fun2(1:T1 / T1)
  
  for (k in 1:K) {
    if (k %in% c(1, 2)) {
      H.arr[k, k, ] <- within.prob1
    } else {
      H.arr[k, k, ] <- within.prob2
    }
  }
  
  for (i in 1:K) {
    for (j in 1:K) {
      for (t in 1:T1) {
        if (i == j) next
        if ((i == 1 & j == 2) | (i == 1 & j == 3) |
            (i == 2 & j == 3) | (i == 2 & j == 1) |
            (i == 3 & j == 1) | (i == 3 & j == 2)) {
          H.arr[i, j, t] <- btw.prob1[t]
        } else {
          H.arr[i, j, t] <- btw.prob2[t]
        }
      }
    }
  }
  
  P.arr <- array(NA, dim = c(n, n, T1))
  A.arr <- array(NA, dim = c(n, n, T1))
  
  for (t in 1:T1) {
    P.arr[, , t] <- M %*% H.arr[, , t] %*% t(M)
    diag(P.arr[, , t]) <- 0
    A.arr[, , t] <- as.matrix(gen.A.from.P(P.arr[, , t]))
  }
  
  res <- list()
  res[[1]] <- A.arr
  res[[2]] <- P.arr
  
  return(res)
}


## RDPG.gen()
## Input : network size n, latent dimension d, and number of time layers T1.
## Output: A list whose first element is the adjacency array and second element
##         is the true probability array.
## Generates a dynamic RDPG model using the FASE spline-based simulator.
RDPG.gen <- function(n = 600, d = 4, T1 = 100) {
  data <- fase::rdpg_snapshot_bs(
    n = n,
    d = d,
    self_loops = FALSE,
    spline_design = list(
      q = 5,
      x_vec = seq(0, 1, length.out = T1),
      x_min = -.1,
      x_max = 1.1
    ),
    process_options = list(
      alpha_coord = .2,
      density = 1 / 10
    )
  )
  
  B_mat1 <- data$spline_design$spline_mat
  W1 <- data$W
  latent <- fase:::WB_to_Theta(W1, B_mat1, self_loops = TRUE)
  
  A.arr <- array(NA, dim = c(n, n, T1))
  for (t in 1:T1) {
    A.arr[, , t] <- as.matrix(gen.A.from.P(latent[, , t]))
  }
  res <- list()
  res[[1]] <- A.arr
  res[[2]] <- latent
  return(res)
}

## DSBM.pd.gen()
## Input : network size n, number of time layers T1, and two signal functions.
## Output: A list whose first element is the adjacency array and second element
##         is the true probability array.
## Generates a degree-scaled dynamic SBM with two time-varying block patterns.
DSBM.pd.gen <- function(n = 600, T1 = 100, fun1 = f111, fun2 = f112) {
  lambda <- n / 20
  beta <- 0.5
  K <- 4
  w <- rep(1, K)
  Pi <- rep(1, K) / K
  
  P0 <- diag(w)
  if (beta > 0) {
    P0 <- matrix(1, K, K)
    diag(P0) <- w / beta
  }
  P <- P0
  M <- matrix(0, n, K)
  membership <- sample(x = K, size = n, replace = TRUE, prob = Pi)
  M[cbind(1:n, membership)] <- 1
  A.bar <- M %*% P %*% t(M)
  H1 <- P * lambda / mean(colSums(A.bar))
  H.arr <- array(0, dim = c(K, K, T1))
  for (t in 1:T1) {
    diag(H.arr[, , t])[1:2] <- diag(H1)[1:2] * fun1(t / T1)
    diag(H.arr[, , t])[3:4] <- diag(H1)[3:4] * fun2(t / T1)
  }
  btw.prob1 <- H1[1, 2] * fun1(1:T1 / T1)
  btw.prob2 <- H1[1, 2] * fun2(1:T1 / T1)
  for (i in 1:K) {
    for (j in 1:K) {
      for (t in 1:T1) {
        if (i == j) next
        if ((i == 1 & j == 2) | (i == 1 & j == 3) |
            (i == 2 & j == 3) | (i == 2 & j == 1) |
            (i == 3 & j == 1) | (i == 3 & j == 2)) {
          H.arr[i, j, t] <- btw.prob1[t]
        } else {
          H.arr[i, j, t] <- btw.prob2[t]
        }
      }
    }
  }
  P.true <- array(0, dim = c(n, n, T1))
  A.arr <- array(NA, dim = c(n, n, T1))
  for (t in 1:T1) {
    P.true[, , t] <- M %*% H.arr[, , t] %*% t(M)
    diag(P.true[, , t]) <- 0
    
    A.arr[, , t] <- as.matrix(gen.A.from.P(P.true[, , t]))
    diag(A.arr[, , t]) <- 0
  }
  
  res <- list()
  res[[1]] <- A.arr
  res[[2]] <- P.true
  
  return(res)
}


## latent.gen()
## Input : network size n, latent dimension d, and number of time layers T1.
## Output: A list whose first element is the adjacency array and second element
##         is the true probability array.
## Generates a dynamic latent distance model from spline-based latent positions.
latent.gen <- function(n, d, T1) {
  data <- fase::rdpg_snapshot_bs(
    n = n,
    d = d,
    self_loops = FALSE,
    spline_design = list(
      q = 8,
      x_vec = seq(-1, 1, length.out = T1),
      x_min = -1.1,
      x_max = 1.1
    ),
    process_options = list(
      alpha_coord = .2,
      density = 1 / 10
    )
  )
  
  B_mat <- data$spline_design$spline_mat
  W <- data$W
  dW <- dim(W)
  m <- nrow(B_mat)
  
  Z <- array(
    apply(W, 3, function(x) x %*% t(B_mat)),
    c(dW[1], m, dW[3])
  )
  
  dist <- array(0, dim = c(n, n, T1))
  
  for (i in 1:n) {
    for (j in 1:n) {
      for (t in 1:T1) {
        if (i == j) next
        dist[i, j, t] <- two.norm(Z[i, t, ] - Z[j, t, ])
      }
    }
  }
  
  P.dist <- array(0, dim = c(n, n, T1))
  
  for (i in 1:n) {
    for (j in 1:n) {
      for (t in 1:T1) {
        P.dist[i, j, t] <- inv.logit(-10 * dist[i, j, t])
        if (i == j) P.dist[i, j, t] <- 0
      }
    }
  }
  A.arr <- array(0, dim = c(n, n, T1))
  for (t in 1:T1) {
    A.arr[, , t] <- as.matrix(gen.A.from.P(P.dist[, , t]))
    diag(A.arr[, , t]) <- 0
  }
  res <- list()
  res[[1]] <- A.arr
  res[[2]] <- P.dist
  return(res)
}


## err_cal()
## Input : P.hat, an n x n x T estimated probability array;
##         true.array, an n x n x T true probability array.
## Output: A list containing raw norm values and relative errors.
## Computes Frobenius, spectral, and two-to-infinity errors by time.
err_cal <- function(P.hat, true.array) {
  T1 <- dim(true.array)[3]
  err.P.f <- rep(NA, T1)
  err.P.spec <- rep(NA, T1)
  err.P.2inf <- rep(NA, T1)
  err.esti.f <- rep(NA, T1)
  err.esti.spec <- rep(NA, T1)
  err.esti.2inf <- rep(NA, T1)
  for (t in seq_len(T1)) {
    err.P.f[t] <- f.norm(true.array[, , t])
    err.P.spec[t] <- spec.norm(true.array[, , t])
    err.P.2inf[t] <- twoinf.norm(true.array[, , t])
    err.esti.f[t] <- f.norm(P.hat[, , t] - true.array[, , t])
    err.esti.spec[t] <- spec.norm(P.hat[, , t] - true.array[, , t])
    err.esti.2inf[t] <- twoinf.norm(P.hat[, , t] - true.array[, , t])
  }
  err <- list()
  err[[1]] <- matrix(0, nrow = T1, ncol = 6)
  err[[1]][, 1] <- err.P.f
  err[[1]][, 2] <- err.P.spec
  err[[1]][, 3] <- err.P.2inf
  err[[1]][, 4] <- err.esti.f
  err[[1]][, 5] <- err.esti.spec
  err[[1]][, 6] <- err.esti.2inf
  err[[2]] <- matrix(0, nrow = T1, ncol = 3)
  err[[2]][, 1] <- err.esti.f / err.P.f
  err[[2]][, 2] <- err.esti.spec / err.P.spec
  err[[2]][, 3] <- err.esti.2inf / err.P.2inf
  return(err)
}