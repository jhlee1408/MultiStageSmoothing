## Main smoothing and cross-validation functions
library(fase)
library(randnet)

## MultiSmooth()
## Input : A_arr, an n x n x T adjacency array; degree; temporal bandwidth h1;
##         neighborhood bandwidth h2.
## Output: A list whose first element is the temporal smoothing result and
##         second element is the temporal + neighborhood smoothing result.
## Computes local polynomial smoothing followed by neighborhood smoothing.
MultiSmooth <- function(A_arr, deg = 0, h1, h2) {
  n  <- dim(A_arr)[1]
  T1 <- dim(A_arr)[3]
  
  temporal_res <- loc_poly_smooth(A_arr, band = h1, deg = deg)
  multi_res <- array(dim = c(n, n, T1))
  
  if (is.null(h2)) {
    h.seq <- sqrt(log(n) / n) * seq(0.5, 3, by = 0.5)
    for (t in seq_len(T1)) {
      CV.res <- ECV.nSmooth.lowrank(temporal_res[, , t], h.seq,
                                    K = 2, B = 3)
      min.idx <- CV.res$min.index
      multi_res[, , t] <- nSmooth(temporal_res[, , t], h = h.seq[min.idx])
    }
  } else {
    for (t in seq_len(T1)) {
      multi_res[, , t] <- nSmooth(temporal_res[, , t], h = h2)
    }
  }
  
  res <- list()
  res[[1]] <- temporal_res
  res[[2]] <- multi_res
  
  return(res)
}


## MultiSmooth_cv()
## Input : A_arr, an n x n x T adjacency array; window size.
## Output: A list containing mean CV errors, candidate grid, and selected best
##         tuning parameters.
## Performs leave-one-layer cross-validation for deg, h1, and h2.
MultiSmooth_cv <- function(A_arr, window = 0) {
  n  <- dim(A_arr)[1]
  T1 <- dim(A_arr)[3]
  
  h1.candi <- exp(seq(-3, 0, length.out = 10))[-10]
  h2.candi <- exp(seq(-3, 0, length.out = 7))[-7]
  deg.candi <- c(0, 1, 2)
  
  t_valid <- seq(window + 1, T1 - window, by = 3)
  
  loc_pol_list <- list()
  for (dg in deg.candi) {
    loc_pol_list[[as.character(dg)]] <- list()
    for (h1 in h1.candi) {
      loc_pol_list[[as.character(dg)]][[as.character(h1)]] <- list()
    }
  }
  
  for (dg in deg.candi) {
    for (h1 in h1.candi) {
      for (tm in t_valid) {
        loc_res <- loc_poly_cv_predict(A_arr, deg = dg, band = h1,
                                       missingLayer = tm)
        pred_mat <- loc_res[, , tm]
        loc_pol_list[[as.character(dg)]][[as.character(h1)]][[as.character(tm)]] <-
          pred_mat
      }
    }
  }
  
  combos <- expand.grid(
    deg = deg.candi,
    h1 = h1.candi,
    h2 = h2.candi,
    KEEP.OUT.ATTRS = FALSE
  )
  
  mean_error <- numeric(nrow(combos))
  
  for (i in seq_len(nrow(combos))) {
    dg <- combos$deg[i]
    h1 <- combos$h1[i]
    h2 <- combos$h2[i]
    errors_t <- numeric(length(t_valid))
    
    for (idx_t in seq_along(t_valid)) {
      tm <- t_valid[idx_t]
      pred_mat <- loc_pol_list[[as.character(dg)]][[as.character(h1)]][[as.character(tm)]]
      multi_pred <- nSmooth(pred_mat, h = h2)
      errors_t[idx_t] <- f.norm(multi_pred - A_arr[, , tm]) / f.norm(A_arr[, , tm])
    }
    
    mean_error[i] <- mean(errors_t)
  }
  
  idx_best <- which.min(mean_error)
  best <- combos[idx_best, ]
  
  return(list(
    mean_errors = mean_error,
    grid = combos,
    best = best
  ))
}


## Helper functions
## ------------------------------------------------------------

## loc_poly_smooth()
## Input : A_arr, an n x n x T adjacency array; polynomial degree; bandwidth.
## Output: P.array, an n x n x T temporally smoothed array.
## Computes the first-step local polynomial smoothing over time.
loc_poly_smooth <- function(A_arr, deg = 1, band = 0.1) {
  n  <- dim(A_arr)[1]
  T1 <- dim(A_arr)[3]
  time_grid <- seq_len(T1) / T1
  
  weight <- function(u, bw) {
    ifelse(abs(u / bw) < 1, (1 - abs(u / bw)^3)^3, 0) / bw
  }
  
  x.array <- array(NA, dim = c(deg + 1, deg + 1, T1))
  x2.array <- array(NA, dim = c(deg + 1, T1, T1))
  
  for (t0 in seq_len(T1)) {
    X <- outer(time_grid - time_grid[t0], 0:deg, `^`)
    W <- diag(weight(time_grid - time_grid[t0], band))
    x.array[, , t0] <- t(X) %*% W %*% X
    x2.array[, , t0] <- t(X) %*% W
  }
  
  nEdges <- n * (n - 1) / 2
  Y <- matrix(NA, nrow = T1, ncol = nEdges)
  
  for (i in seq_len(n)) {
    for (j in seq_len(n)) {
      if (i >= j) next
      colIndex <- (j - 1) * (j - 2) / 2 + i
      Y[, colIndex] <- A_arr[i, j, ]
    }
  }
  
  P.array <- array(0, dim = c(n, n, T1))
  
  for (t0 in seq_len(T1)) {
    if (sum(x2.array[, , t0] == 0) == (deg + 1) * T1) {
      beta <- matrix(0, nrow = deg + 1, ncol = nEdges)
    } else {
      beta <- solve(x.array[, , t0], x2.array[, , t0] %*% Y)
    }
    
    P.array[, , t0][upper.tri(P.array[, , t0])] <- beta[1, ]
    P.array[, , t0][lower.tri(P.array[, , t0])] <-
      t(P.array[, , t0])[lower.tri(P.array[, , t0])]
  }
  
  return(P.array)
}


## loc_poly_cv_predict()
## Input : A_arr, an n x n x T adjacency array; degree; bandwidth;
##         optional missing layer index for leave-one-layer prediction.
## Output: P.array, an n x n x T temporally smoothed array.
## Computes local polynomial smoothing with optional missing-layer exclusion.
loc_poly_cv_predict <- function(A_arr, deg = 1, band = 0.1,
                                missingLayer = NULL) {
  weight <- function(u, bw) {
    ifelse(abs(u / bw) < 1, (1 - abs(u / bw)^3)^3, 0) / bw
  }
  
  n  <- dim(A_arr)[1]
  T1 <- dim(A_arr)[3]
  tFull <- seq_len(T1) / T1
  
  if (!is.null(missingLayer)) {
    useIndex <- setdiff(seq_len(T1), missingLayer)
  } else {
    useIndex <- seq_len(T1)
  }
  
  tUse <- tFull[useIndex]
  nEdges <- n * (n - 1) / 2
  Y <- matrix(NA, nrow = length(useIndex), ncol = nEdges)
  
  for (i in seq_len(n)) {
    for (j in seq_len(n)) {
      if (i >= j) next
      colIndex <- (j - 1) * (j - 2) / 2 + i
      Y[, colIndex] <- A_arr[i, j, useIndex]
    }
  }
  
  P.array <- array(0, dim = c(n, n, T1))
  beta <- matrix(0, nrow = deg + 1, ncol = nEdges)
  
  for (t0 in seq_len(T1)) {
    X <- outer(tUse - tFull[t0], 0:deg, `^`)
    W <- diag(weight(tUse - tFull[t0], band))
    
    XtW  <- t(X) %*% W
    XtWX <- XtW %*% X
    XtWY <- XtW %*% Y
    
    if (qr(XtWX)$rank < (deg + 1)) {
      P.array[, , t0][upper.tri(P.array[, , t0])] <- beta[1, ]
    } else {
      beta <- qr.solve(XtWX, XtWY)
      P.array[, , t0][upper.tri(P.array[, , t0])] <- beta[1, ]
    }
    
    P.array[, , t0][lower.tri(P.array[, , t0])] <-
      t(P.array[, , t0])[lower.tri(P.array[, , t0])]
  }
  
  return(P.array)
}


## Comparison functions
## ------------------------------------------------------------
## ReversedMultiSmooth()
## Input : A_arr, an n x n x T adjacency array; degree; temporal bandwidth h1;
##         neighborhood bandwidth h2.
## Output: A list whose first element is the neighborhood smoothing result and
##         second element is the neighborhood + temporal smoothing result.
## Computes neighborhood smoothing followed by local polynomial smoothing.
ReversedMultiSmooth <- function(A_arr, deg = 0, h1 = 0.1, h2 = 0.1) {
  n  <- dim(A_arr)[1]
  T1 <- dim(A_arr)[3]
  
  nn.res <- array(0, dim = c(n, n, T1))
  
  if (is.null(h2)) {
    h.seq <- sqrt(log(n) / n) * seq(0.5, 3, by = 0.5)
    
    for (t in seq_len(T1)) {
      CV.res <- ECV.nSmooth.lowrank(A_arr[, , t], h.seq,
                                    K = 2, B = 3)
      min.idx <- CV.res$min.index
      nn.res[, , t] <- nSmooth(A_arr[, , t], h = h.seq[min.idx])
    }
  } else {
    for (t in seq_len(T1)) {
      nn.res[, , t] <- nSmooth(A_arr[, , t], h = h2)
    }
  }
  
  reversed.res <- loc_poly_smooth(nn.res, deg = deg, band = h1)
  
  res <- list()
  res[[1]] <- nn.res
  res[[2]] <- reversed.res
  
  return(res)
}


## FASE_compare()
## Input : A_arr, an n x n x T adjacency array.
## Output: Estimated probability array from FASE.
## Selects d and q by NGCV and reconstructs probability matrices.
FASE_compare <- function(A_arr) {
  n  <- dim(A_arr)[1]
  T1 <- dim(A_arr)[3]
  
  d.seq <- seq(2, 5)
  q.seq <- seq(6, 11, by = 1)
  hyp <- expand.grid(d = d.seq, q = q.seq)
  hyp.ngcv <- rep(0, nrow(hyp))
  for (k in seq_len(nrow(hyp))) {
    fase.latent <- fase::fase(
      A_arr,
      d = hyp$d[k],
      self_loops = FALSE,
      spline_design = list(type = "bs", q = hyp$q[k]),
      output_options = list(
        return_coords = TRUE,
        return_ngcv = TRUE
      )
    )
    hyp.ngcv[k] <- fase.latent$ngcv
  }
  best.idx <- which.min(hyp.ngcv)
  d.best <- hyp$d[best.idx]
  q.best <- hyp$q[best.idx]
  fase.latent <- fase::fase(
    A_arr,
    d = d.best,
    self_loops = FALSE,
    spline_design = list(type = "bs", q = q.best),
    output_options = list(
      return_coords = TRUE,
      return_ngcv = TRUE
    )
  )
  P.fase <- array(0, dim = c(n, n, T1))
  for (t in seq_len(T1)) {
    P.fase[, , t] <- fase.latent$Z[, , t] %*%
      t(fase.latent$Z[, , t])
  }
  return(P.fase)
}


## Pensky_compare()
## Input : A_arr, an n x n x T adjacency array; order l; candidate grid r_grid.
## Output: Estimated probability array using Pensky-Zhang adaptive smoothing.
## Selects r by Lepski's rule and optionally applies dynamic SBM refitting.
Pensky_compare <- function(A_arr, l = 2, r_grid = NULL, C0_tau = 1,
                           m0 = 0, refit = FALSE, varpi = 0.5,
                           nstart = 20, maxK = NULL,
                           return_all = FALSE) {
  n  <- dim(A_arr)[1]
  T1 <- dim(A_arr)[3]
  if (is.null(r_grid)) r_grid <- 0:floor(T1 / 2)
  r_grid <- sort(unique(r_grid))
  P_list <- setNames(
    lapply(r_grid, function(r) pensky_estimate_P(A_arr, r, l, m0)),
    as.character(r_grid)
  )
  alpha_hat <- setNames(
    sapply(r_grid, function(r) pensky_alpha(A_arr, r)),
    as.character(r_grid)
  )
  admissible <- setNames(rep(TRUE, length(r_grid)), as.character(r_grid))
  for (r in r_grid) {
    smaller_r <- r_grid[r_grid < r]
    if (length(smaller_r) == 0) next
    P_r <- P_list[[as.character(r)]]
    for (rho in smaller_r) {
      P_rho <- P_list[[as.character(rho)]]
      disc <- mean(sapply(seq_len(T1), function(t) {
        pensky_mat_norm(P_r[, , t] - P_rho[, , t])
      }))
      thr <- 4 * C0_tau * sqrt(n * alpha_hat[as.character(rho)] / max(rho, 1))
      
      if (disc > thr) {
        admissible[as.character(r)] <- FALSE
        break
      }
    }
  }
  r_hat <- max(r_grid[admissible])
  P_hat <- P_list[[as.character(r_hat)]]
  if (refit) {
    P_hat <- pensky_sbm_refit(P_hat, varpi = varpi,
                              nstart = nstart, maxK = maxK)
  }
  if (return_all) {
    return(list(
      P_hat = P_hat,
      r_hat = r_hat,
      r_grid = r_grid,
      admissible = admissible,
      alpha_hat = alpha_hat
    ))
  }
  return(P_hat)
}


#---------------------------------------
# helper function for Pensky's method
#---------------------------------------
## Helper functions
## ------------------------------------------------------------

Phk <- function(h, k, r) {
  i <- 0:(r - 1)
  r^(-(h + k + 1)) * sum((i^h) * ((r - i)^k))
}

pensky_kernel <- function(t, T1, r, l, m0 = 0) {
  if (r == 0) return(list(offsets = 0, weights = 1))
  
  if (t >= 1 + r && t <= T1 - r) {
    l0 <- floor(l / 2)
    m <- l0
    K <- matrix(0, nrow = l0 + 1, ncol = m + 1)
    
    for (j in 0:m) K[1, j + 1] <- 1 + 2 * r * Phk(j + m0, 0, r)
    if (l0 >= 1) {
      for (k0 in 1:l0) {
        for (j in 0:m) K[k0 + 1, j + 1] <- Phk(j + m0, 2 * k0, r)
      }
    }
    
    a <- solve(K, c(2 * r + 1, rep(0, l0)))
    offsets <- (-r):r
    
  } else {
    left <- t <= r
    m <- l
    K <- matrix(0, nrow = l + 1, ncol = m + 1)
    
    for (j in 0:m) K[1, j + 1] <- 1 + r * Phk(j + m0, 0, r)
    if (l >= 1) {
      for (k in 1:l) {
        for (j in 0:m) K[k + 1, j + 1] <- Phk(j + m0, k, r)
      }
    }
    
    a <- solve(K, c(r + 1, rep(0, l)))
    offsets <- if (left) 0:r else (-r):0
  }
  
  weights <- sapply(offsets, function(i) {
    u <- if (t >= 1 + r && t <= T1 - r) r - abs(i) else r - abs(i)
    sum(a * (u / r)^(0:m + m0))
  })
  
  list(offsets = offsets, weights = as.numeric(weights))
}


pensky_estimate_P <- function(A_arr, r, l, m0 = 0) {
  n  <- dim(A_arr)[1]
  T1 <- dim(A_arr)[3]
  P_hat <- array(0, dim = c(n, n, T1))
  
  for (t in seq_len(T1)) {
    ker <- pensky_kernel(t, T1, r, l, m0)
    est <- matrix(0, n, n)
    
    for (j in seq_along(ker$offsets)) {
      est <- est + ker$weights[j] * A_arr[, , t + ker$offsets[j]]
    }
    
    est <- est / length(ker$offsets)
    est <- (est + t(est)) / 2
    diag(est) <- 0
    P_hat[, , t] <- est
  }
  
  return(P_hat)
}

pensky_alpha <- function(A_arr, r) {
  n  <- dim(A_arr)[1]
  T1 <- dim(A_arr)[3]
  if (r == 0) {
    return(max(sapply(seq_len(T1), function(t) {
      norm(A_arr[, , t], type = "I") / n
    })))
  }
  valid_t <- (r + 1):(T1 - r)
  max(sapply(valid_t, function(t) {
    idx <- (t - r):(t + r)
    Msum <- apply(A_arr[, , idx, drop = FALSE], c(1, 2), sum)
    norm(Msum, type = "I") / (n * (2 * r + 1))
  }))
}

pensky_mat_norm <- function(M) {
  d <- svd(M, nu = 0, nv = 0)$d
  if (length(d) == 0) 0 else d[1]
}

pensky_sbm_refit <- function(P_hat, varpi = 0.5, nstart = 20, maxK = NULL) {
  n  <- dim(P_hat)[1]
  T1 <- dim(P_hat)[3]
  if (is.null(maxK)) maxK <- min(n - 1, 10)
  eig_sum <- rep(0, maxK + 1)
  eig_vecs <- vector("list", T1)
  for (t in seq_len(T1)) {
    ee <- eigen(P_hat[, , t], symmetric = TRUE)
    ord <- order(abs(ee$values), decreasing = TRUE)
    eig_sum <- eig_sum + abs(ee$values[ord])[1:(maxK + 1)]
    eig_vecs[[t]] <- ee$vectors[, ord, drop = FALSE]
  }
  K_hat <- min(which(eig_sum[2:(maxK + 1)] < varpi * eig_sum[1:maxK]))
  if (!is.finite(K_hat)) K_hat <- maxK
  P_block <- array(0, dim = c(n, n, T1))
  for (t in seq_len(T1)) {
    U <- eig_vecs[[t]][, 1:K_hat, drop = FALSE]
    z <- kmeans(U, centers = K_hat, nstart = nstart)$cluster
    Theta <- matrix(0, n, K_hat)
    Theta[cbind(seq_len(n), z)] <- 1
    B <- matrix(0, K_hat, K_hat)
    for (k in seq_len(K_hat)) {
      ik <- which(z == k)
      nk <- length(ik)
      for (l in k:K_hat) {
        il <- which(z == l)
        nl <- length(il)
        if (k == l && nk > 1) {
          B[k, k] <- sum(P_hat[ik, ik, t]) / (nk * (nk - 1))
        }
        if (k != l) {
          B[k, l] <- mean(P_hat[ik, il, t])
          B[l, k] <- B[k, l]
        }
      }
    }
    P_block[, , t] <- Theta %*% B %*% t(Theta)
    diag(P_block[, , t]) <- 0
  }
  return(P_block)
}