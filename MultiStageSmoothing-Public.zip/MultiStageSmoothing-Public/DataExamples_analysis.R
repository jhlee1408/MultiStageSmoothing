## ============================================================
## Cosponsorship network: cluster trajectories and polarization
## ============================================================
library(ggplot2)
library(cluster)
library(scales)
library(RColorBrewer)

OUTPUT_DIR <- "figures"

if (!dir.exists(OUTPUT_DIR)) {
  dir.create(OUTPUT_DIR, recursive = TRUE)
}

## ---- Source functions --------------------------------------
source("MultiStage_main.R")
source("MultiStage_helper.R")

## ---- Load preprocessed data --------------------------------
A_arr       <- readRDS("Data/Cosponsor_Adj.rds")
party_state_mat <- readRDS("Data/Party_State_Mat.rds")

states <- dimnames(A_arr)[[1]]
years  <- as.integer(dimnames(A_arr)[[3]])
n      <- length(states)
T_len  <- length(years)

## ---- Estimate affiliation matrices -------------------------
cv_res <- MultiSmooth_cv(A_arr)
best   <- cv_res$best
P_fit <- MultiSmooth(
  A_arr,
  deg = best$deg,
  h1  = best$h1,
  h2  = best$h2
)

P_mats <- P_fit[[2]]
dimnames(P_mats) <- dimnames(A_arr)

## ============================================================
## 1. State clustering based on full affiliation profiles
## ============================================================
profile_mat <- matrix(0, nrow = n, ncol = n * T_len)
for (i in seq_len(n)) {
  for (t in seq_len(T_len)) {
    profile_mat[i, ((t - 1) * n + 1):(t * n)] <- P_mats[i, , t]
  }
}

rownames(profile_mat) <- states
sim_raw <- cor(t(profile_mat))
diag(sim_raw) <- 0
sim_ss   <- (sim_raw + 1) / 2
dist_mat <- as.dist(1 - sim_ss)
hc <- hclust(dist_mat, method = "ward.D2")

sil_k <- sapply(2:6, function(k) {
  cl  <- cutree(hc, k = k)
  sil <- cluster::silhouette(cl, dist_mat)
  mean(sil[, 3])
})

print(sil_k)

K <- 4

labels_best <- cutree(hc, k = K)
names(labels_best) <- states

cl_result <- data.frame(
  state = states,
  label = labels_best
)

split(cl_result$state, cl_result$label)
print(table(cl_result$label))

cols <- brewer.pal(8, "Dark2")
cluster_palette <- c(
  "1" = cols[1], "2" = cols[2], "3" = cols[3], "4" = cols[4]
)

## ============================================================
## 2. Mean within-cluster affiliation trajectories
##    Saved as fig2.pdf
## ============================================================
wc_mean <- matrix(NA_real_, nrow = T_len, ncol = K)
colnames(wc_mean) <- as.character(1:K)
for (cl in 1:K) {
  members <- which(labels_best == cl)
  if (length(members) < 2) next
  wc_mean[, as.character(cl)] <- sapply(seq_len(T_len), function(t) {
    sub <- P_mats[members, members, t]
    mean(sub[upper.tri(sub)])
  })
}

df_wc <- data.frame(
  year    = rep(years, K),
  affil   = as.vector(wc_mean),
  cluster = factor(rep(1:K, each = T_len))
)

fig2 <- ggplot(
  df_wc,
  aes(
    x = year,
    y = affil,
    color = cluster,
    linetype = cluster,
    group = cluster
  )
) +
  geom_line(linewidth = 1.2) +
  scale_color_manual(
    values = cluster_palette,
    labels = paste0("Cluster ", 1:K),
    name = "Cluster"
  ) +
  scale_linetype_manual(
    values = c("solid", "dashed", "dotdash", "dotted"),
    labels = paste0("Cluster ", 1:K),
    name = "Cluster"
  ) +
  scale_x_continuous(breaks = seq(1973, 2024, by = 5)) +
  labs(
    x = "Year",
    y = "Mean Affiliation Score"
  ) +
  theme_bw(base_size = 12) +
  theme(
    legend.position  = "bottom",
    legend.title     = element_text(size = 16),
    legend.text      = element_text(size = 15),
    axis.title.x     = element_text(size = 18),
    axis.title.y     = element_text(size = 18),
    axis.text.x      = element_text(size = 15),
    axis.text.y      = element_text(size = 15),
    legend.key.width = unit(2.2, "cm"),
    plot.title       = element_text(face = "bold")
  )

print(fig2)

ggsave(
  filename = file.path(OUTPUT_DIR, "fig2.pdf"),
  plot = fig2,
  width = 1400 / 120,
  height = 700 / 120,
  units = "in"
)


## ============================================================
## 3. State-level within-cluster trajectories
##    Saved separately by cluster
## ============================================================
cluster_vec <- as.integer(labels_best)
df_state <- do.call(rbind, lapply(seq_len(T_len), function(k) {
  P_t <- P_mats[, , k]
  do.call(rbind, lapply(sort(unique(cluster_vec)), function(cl) {
    idx <- which(cluster_vec == cl)
    if (length(idx) < 2) return(NULL)
    P_sub <- P_t[idx, idx, drop = FALSE]
    diag(P_sub) <- NA
    data.frame(
      state = states[idx],
      cluster = factor(cl),
      year = years[k],
      prob = rowMeans(P_sub, na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  }))
}))

for (cl in sort(unique(df_state$cluster))) {
  df_cl <- subset(df_state, cluster == cl)
  p_cl <- ggplot(
    df_cl,
    aes(x = year, y = prob, group = state, color = cluster)
  ) +
    geom_line(linewidth = 0.45, alpha = 0.65) +
    scale_color_manual(values = cluster_palette, guide = "none") +
    scale_x_continuous(breaks = seq(1975, 2020, by = 10)) +
    coord_cartesian(ylim = c(0, 1)) +
    labs(
      x = "Year",
      y = "Estimated Probability"
    ) +
    theme_bw(base_size = 12) +
    theme(
      legend.position = "none",
      plot.margin = margin(5, 5, 5, 5),
      axis.title.x = element_text(size = 18),
      axis.title.y = element_text(size = 18),
      axis.text.x  = element_text(size = 15),
      axis.text.y  = element_text(size = 15)
    )
  ggsave(
    filename = file.path(OUTPUT_DIR, paste0("fig2_cluster_", cl, ".pdf")),
    plot = p_cl,
    width = 5.2,
    height = 3.5,
    units = "in"
  )
}

## ============================================================
## 4. Time-varying party-status polarization score
##    Final paper figure: presidential overlay
##    Saved as fig3.pdf
## ============================================================
labels_mat <- party_state_mat
R2_t_3way <- sapply(seq_len(T_len), function(t) {
  P_t   <- P_mats[, , t]
  lbl_t <- labels_mat[, t]
  valid <- !is.na(lbl_t) & lbl_t %in% c("DD", "RR", "Mixed")
  if (sum(valid) < 4 || length(unique(lbl_t[valid])) < 2) {
    return(NA_real_)
  }
  P_sub   <- P_t[valid, valid, drop = FALSE]
  lbl_sub <- lbl_t[valid]
  ui <- which(upper.tri(P_sub), arr.ind = TRUE)
  x  <- P_sub[ui]
  ci <- lbl_sub[ui[, 1]]
  cj <- lbl_sub[ui[, 2]]
  
  gm <- mean(x)
  SS_total <- sum((x - gm)^2)
  
  if (SS_total == 0) return(NA_real_)
  ptype <- paste(pmin(ci, cj), pmax(ci, cj), sep = "-")
  gmeans <- tapply(x, ptype, mean)
  sum((gmeans[ptype] - gm)^2) / SS_total
})

r2_df_3way <- data.frame(
  year = years,
  r2 = R2_t_3way
)

pres_df <- data.frame(
  xmin  = c(1973, 1977, 1981, 1993, 2001, 2009, 2017, 2021),
  xmax  = c(1977, 1981, 1993, 2001, 2009, 2017, 2021, 2025),
  party = c("R",  "D",  "R",  "D",  "R",  "D",  "R",  "D")
)

peaks_df <- data.frame(
  year  = c(2003, 2018),
  label = c(
    "Peak under W. Bush\n(after 8-yr Clinton)",
    "Peak under Trump\n(after 8-yr Obama)"
  )
)

fig3 <- ggplot() +
  geom_rect(
    data = pres_df,
    aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = party),
    alpha = 0.20,
    inherit.aes = FALSE
  ) +
  scale_fill_manual(
    values = c("D" = "#5577CC", "R" = "#CC4444"),
    labels = c("D" = "Democrat", "R" = "Republican"),
    name = "Presidential Party"
  ) +
  geom_vline(
    data = peaks_df,
    aes(xintercept = year),
    linetype = "solid",
    color = "#222222",
    linewidth = 0.5,
    alpha = 0.7
  ) +
  geom_label(
    data = peaks_df,
    aes(x = year, y = 0.88, label = label),
    size = 4.5,
    fill = "white",
    color = "#111111",
    label.size = 0.3,
    lineheight = 0.9,
    label.padding = unit(0.35, "lines"),
    label.r = unit(0.15, "lines")
  ) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "grey50",
    linewidth = 0.5
  ) +
  geom_line(
    data = r2_df_3way,
    aes(x = year, y = r2),
    color = "#111111",
    linewidth = 1.3
  ) +
  geom_point(
    data = r2_df_3way,
    aes(x = year, y = r2),
    color = "#111111",
    size = 1.4,
    alpha = 0.8
  ) +
  scale_x_continuous(
    breaks = seq(1973, 2024, by = 5),
    limits = c(1973, 2025)
  ) +
  scale_y_continuous(
    limits = c(0, 0.95),
    breaks = seq(0, 0.9, 0.1),
    labels = scales::percent_format(accuracy = 1)
  ) +
  labs(
    x = "Year",
    y = expression(R^2*(t))
  ) +
  theme_bw(base_size = 12) +
  theme(
    legend.position = "bottom",
    legend.key.size = unit(0.5, "cm"),
    legend.title    = element_text(size = 16),
    legend.text     = element_text(size = 15),
    axis.title.x    = element_text(size = 18),
    axis.title.y    = element_text(size = 18),
    axis.text.x     = element_text(size = 15),
    axis.text.y     = element_text(size = 15)
  )

print(fig3)

ggsave(
  filename = file.path(OUTPUT_DIR, "fig3.pdf"),
  plot = fig3,
  width = 1400 / 120,
  height = 700 / 120,
  units = "in"
)