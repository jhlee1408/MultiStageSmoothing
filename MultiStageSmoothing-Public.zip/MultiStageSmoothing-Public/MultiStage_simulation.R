## Do parallel simulation
## ------------------------------------------------------------
library(doParallel)

source("MultiStage_main.R")
source("MultiStage_helper.R")

n <- 600
T1 <- 100
n_rep <- 100
n_cores <- 15
seed <- 1

out_dir <- "all_results"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
cl <- makeCluster(n_cores)
registerDoParallel(cl)
clusterEvalQ(cl, {
  source("MultiStage_main.R")
  source("MultiStage_helper.R")
})

## Method wrappers
method_list <- list(
  ours = function(A_arr) {
    #cv_res <- as.numeric(MultiSmooth_cv(A_arr, window = 10)$best)
    res <- MultiSmooth(A_arr, deg = 0, h1 = 0.1, h2 = 0.1)
    res[[2]]
  },
  reversed = function(A_arr) {
    res <- ReversedMultiSmooth(A_arr, deg = 0, h1 = 0.1, h2 = 0.1)
    res[[2]]
  },
  fase = function(A_arr) {
    FASE_compare(A_arr)
  },
  pensky = function(A_arr) {
    Pensky_compare(A_arr, l = 2, refit = FALSE)
  },
  pooled = function(A_arr) {
    mean_nS(A_arr)
  },
  indep_nsmooth = function(A_arr) {
    nn(A_arr)
  }
)

## Data-generating model wrappers
gen_list <- list(
  dsbm = function() {
    DSBM.gen(n = n, K = 4, T1 = T1)
  },
  dsbm_orth = function() {
    DSBM.orth.gen(n = n, K = 4, T1 = T1)
  },
  rdpg = function() {
    RDPG.gen(n = n, d = 4, T1 = T1)
  },
  latent = function() {
    latent.gen(n = n, d = 4, T1 = T1)
  }
)

## Simulation runner
run_simulation <- function(gen_fun, method_fun, n_rep = 100, seed = 1) {
  set.seed(seed)
  foreach(
    b = seq_len(n_rep),
    .packages = c("randnet", "HCD", "fase")
  ) %dopar% {
    dat <- gen_fun()
    A_arr <- dat[[1]]
    P_true <- dat[[2]]
    P_hat <- method_fun(A_arr)
    err_cal(P_hat, P_true)
  }
}

## Run all models and all methods
err_names <- character(0)
for (gen_name in names(gen_list)) {
  for (method_name in names(method_list)) {
    st <- Sys.time()
    obj_name <- paste0("err_", gen_name, "_", method_name)
    assign(
      obj_name,
      run_simulation(
        gen_fun = gen_list[[gen_name]],
        method_fun = method_list[[method_name]],
        n_rep = n_rep,
        seed = seed
      )
    )
    err_names <- c(err_names, obj_name)
    print(paste(obj_name, "finished."))
    print(Sys.time() - st)
  }
}
save(
  list = err_names,
  file = file.path(out_dir, "simulation_errors.RData")
)
stopCluster(cl)